package com.zensar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;

@SpringBootApplication
@EnableEurekaClient
@RestController
public class ServiceApplication {
	@Autowired
	private EurekaClient client;
	
	@Autowired
	private RestTemplateBuilder restTemplateBuilder;
	
	@Value("${server.instance.name}")
	private String instanceName;
	
	public static void main(String[] args) {
		SpringApplication.run(ServiceApplication.class, args);
	}
	
	@GetMapping
	public String sayHello() {
		return "<h1> Welcome to service "+ instanceName +" </h1>";
	}
	/*
	 * @GetMapping("/service") public String sayHello1() { RestTemplate
	 * restTemplate= restTemplateBuilder.build();
	 * 
	 * InstanceInfo info=client.getNextServerFromEureka("client", false); String
	 * homePageUrl=info.getHomePageUrl();
	 * System.out.println("HOME PAGE--------->>>"+homePageUrl);
	 * 
	 * ResponseEntity<String> exchange= restTemplate.exchange(homePageUrl,
	 * HttpMethod.GET, null,String.class); String body=exchange.getBody(); return
	 * body; }
	 */
}
